package p11;

import java.util.Scanner;

public class P11 {

    public static void main(String[] args) {
        int ja = 0, al, i;
        Scanner input = new Scanner(System.in);
        AlatMandi alman = new AlatMandi();
        AlatTulis altu = new AlatTulis();
        AlatKesehatan alkes = new AlatKesehatan();
        System.out.print("Masukan Jumlah Alat = ");
        al = input.nextInt();
        for (i = 1; i <= al; i++) {
            System.out.println(" ");
            System.out.println("Jenis Alat");
            System.out.println("1. Alat Mandi");
            System.out.println("2. Alat Tulis");
            System.out.println("3. Alat Kesehatan");
            System.out.println(" ");
            System.out.print("Masukan Jenis Alat ke-" + i + " = ");
            ja = input.nextInt();
            switch (ja) {
                case 1:
                    alman.nama();
                    alman.merk();
                    alman.hargabeli();
                    alman.wujud();
                    alman.warna();
                    System.out.println(" ");
                    break;
                case 2:
                    altu.nama();
                    altu.merk();
                    altu.hargabeli();
                    altu.fungsi();
                    altu.dimensi();
                    System.out.println(" ");
                    break;
                case 3:
                    alkes.nama();
                    alkes.merk();
                    alkes.hargabeli();
                    alkes.jenis();
                    alkes.manfaat();
                    System.out.println(" ");
                    break;
                default:
                    break;
            }
            
        
        System.out.println("||------------------------||");
        System.out.println("||---------output---------||");
        System.out.println("||------------------------||");
        switch (ja) {
            case 1:
                System.out.println("Nama = " + alman.masuk000);
                System.out.println("Merk = " + alman.masuk00);
                System.out.println("Harga = " + alman.masuk0);
                System.out.println("Wujud = " + alman.masuk);
                System.out.println("Warna = " + alman.masuk1);
                System.out.println("\n------------------------\n");
                break;
            case 2:
                System.out.println("Nama = " + altu.masuk000);
                System.out.println("Merk = " + altu.masuk00);
                System.out.println("Harga = " + altu.masuk0);
                System.out.println("Fungsi = " + altu.masuk5);
                System.out.println("Dimensi = " + altu.masuk6+"x"+ altu.masuk61);
                System.out.println("\n------------------------\n");
                break;
            case 3:
                System.out.println("Nama = " + alkes.masuk000);
                System.out.println("Merk = " + alkes.masuk00);
                System.out.println("Harga = " + alkes.masuk0);
                System.out.println("Jenis = " + alkes.masuk7);
                System.out.println("Manfaat = " + alkes.masuk8);
                System.out.println("\n------------------------\n");
                break;
            default:
                break;

        }
        }
        
        

    }
}

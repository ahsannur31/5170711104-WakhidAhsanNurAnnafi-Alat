package p11;

public class AlatTulis extends Alat {

    void fungsi() {
        System.out.print("Fungsi = ");
        masuk5 = input.next();
    }

    void dimensi() {
        System.out.println("Dimensi(PxL)");
        System.out.print("P : ");
        masuk6 = input.nextInt();
        System.out.print("L : ");
        masuk61 = input.nextInt();
    }

}

package p11;
import java.util.Scanner;

public class Alat {
String  masuk00,masuk000, masuk, masuk1,masuk5,masuk7,masuk8;
double masuk0;
int masuk6,masuk61;
Scanner input = new Scanner(System.in);
    void hargabeli() {
        System.out.print("Masukan Harga Beli  = ");
        masuk0 = input.nextDouble();
    }

    void merk() {
        System.out.print("Masukan Merk Barang = ");
        masuk00 = input.next();
    }

    void nama() {
        System.out.print("Masukan Nama Barang = ");
        masuk000 = input.next();
    }

}

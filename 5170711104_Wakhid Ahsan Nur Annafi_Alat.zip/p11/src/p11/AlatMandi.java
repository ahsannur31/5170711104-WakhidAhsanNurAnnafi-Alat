package p11;

public class AlatMandi extends Alat {

    void wujud() {
        System.out.print("Wujud Barang = ");
        masuk = input.next();
    }

    void warna() {
        System.out.print("Warna Barang = ");
        masuk1 = input.next();
       
    }


}

package p11;

public class AlatKesehatan extends Alat {
   void jenis() {
        System.out.print("jinis AlKes  = ");
        masuk7 = input.next();
    }

    void manfaat() {
        System.out.print("Manfaat = ");
        masuk8 = input.next();
    } 

}
